from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user
from app import mysql
import MySQLdb.cursors
from datetime import datetime
import os
from werkzeug.utils import secure_filename

main_bp = Blueprint('main', __name__)
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def format_datetime(data, keys):
    for item in data:
        for key, fmt in keys.items():
            try:
                item[key] = datetime.strptime(item[f'formatted_{key}'], fmt)
            except (ValueError, TypeError):
                item[key] = datetime.now()
    return data

@main_bp.route('/')
def index():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('''
        SELECT e.*, COUNT(er.id) as registered_count,
        DATE_FORMAT(e.date, '%%Y-%%m-%%d') as formatted_date,
        DATE_FORMAT(e.time, '%%H:%%i:%%s') as formatted_time
        FROM events e 
        LEFT JOIN event_registrations er ON e.id = er.event_id 
        WHERE e.status = 'published' AND e.date >= CURDATE()
        GROUP BY e.id 
        ORDER BY e.date ASC
    ''')
    events = format_datetime(cursor.fetchall(), {'date': '%Y-%m-%d', 'time': '%H:%M:%S'})
    cursor.close()
    return render_template('main/index.html', events=events)

@main_bp.route('/event/<int:event_id>')
def event_details(event_id):
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('''
        SELECT e.*, COUNT(er.id) as registered_count,
        DATE_FORMAT(e.date, '%%Y-%%m-%%d') as formatted_date,
        DATE_FORMAT(e.time, '%%H:%%i:%%s') as formatted_time
        FROM events e 
        LEFT JOIN event_registrations er ON e.id = er.event_id 
        WHERE e.id = %s
        GROUP BY e.id
    ''', (event_id,))
    event = cursor.fetchone()
    if event:
        format_datetime([event], {'date': '%Y-%m-%d', 'time': '%H:%M:%S'})

    is_registered = False
    if current_user.is_authenticated:
        cursor.execute('''
            SELECT * FROM event_registrations 
            WHERE event_id = %s AND user_id = %s
        ''', (event_id, current_user.id))
        is_registered = cursor.fetchone() is not None

    cursor.close()
    return render_template('main/event_details.html', event=event, is_registered=is_registered)

@main_bp.route('/event/<int:event_id>/register', methods=['POST'])
@login_required
def register_event(event_id):
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('''
        SELECT e.*, COUNT(er.id) as registered_count 
        FROM events e 
        LEFT JOIN event_registrations er ON e.id = er.event_id 
        WHERE e.id = %s
        GROUP BY e.id
    ''', (event_id,))
    event = cursor.fetchone()

    if not event:
        flash('Event not found', 'error')
    elif event['registered_count'] >= event['capacity']:
        flash('Event is full', 'error')
    else:
        try:
            cursor.execute('''
                INSERT INTO event_registrations (event_id, user_id)
                VALUES (%s, %s)
            ''', (event_id, current_user.id))
            mysql.connection.commit()
            flash('Successfully registered for the event!', 'success')
        except MySQLdb.IntegrityError:
            flash('You are already registered for this event', 'error')

    cursor.close()
    return redirect(url_for('main.event_details', event_id=event_id))

@main_bp.route('/request-event', methods=['GET', 'POST'])
@login_required
def request_event():
    if request.method == 'POST':
        data = request.form
        image_filename = None

        if 'image' in request.files:
            image = request.files['image']
            if image and allowed_file(image.filename):
                filename = secure_filename(image.filename)
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                image_filename = f"{timestamp}_{filename}"
                image.save(os.path.join(UPLOAD_FOLDER, image_filename))

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('''
            INSERT INTO event_requests 
            (title, description, proposed_date, proposed_time, location, capacity, requested_by, image_url)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ''', (data.get('title'), data.get('description'), data.get('date'), data.get('time'),
              data.get('location'), data.get('capacity'), current_user.id, image_filename))
        mysql.connection.commit()
        cursor.close()

        flash('Event request submitted successfully!', 'success')
        return redirect(url_for('main.my_requests'))

    return render_template('main/request_event.html')

@main_bp.route('/my-requests')
@login_required
def my_requests():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('''
        SELECT *, 
        DATE_FORMAT(proposed_date, '%%Y-%%m-%%d') as formatted_proposed_date,
        DATE_FORMAT(proposed_time, '%%H:%%i:%%s') as formatted_proposed_time,
        DATE_FORMAT(created_at, '%%Y-%%m-%%d %%H:%%i:%%s') as formatted_created_at
        FROM event_requests 
        WHERE requested_by = %s 
        ORDER BY created_at DESC
    ''', (current_user.id,))
    requests = format_datetime(cursor.fetchall(), {
        'proposed_date': '%Y-%m-%d',
        'proposed_time': '%H:%M:%S',
        'created_at': '%Y-%m-%d %H:%M:%S'
    })
    cursor.close()
    return render_template('main/my_requests.html', requests=requests)

@main_bp.route('/my-registrations')
@login_required
def my_registrations():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('''
        SELECT e.*, er.registration_date,
        DATE_FORMAT(e.date, '%%Y-%%m-%%d') as formatted_date,
        DATE_FORMAT(e.time, '%%H:%%i:%%s') as formatted_time,
        DATE_FORMAT(er.registration_date, '%%Y-%%m-%%d %%H:%%i:%%s') as formatted_registration_date
        FROM events e 
        JOIN event_registrations er ON e.id = er.event_id 
        WHERE er.user_id = %s 
        ORDER BY e.date ASC
    ''', (current_user.id,))
    registrations = format_datetime(cursor.fetchall(), {
        'date': '%Y-%m-%d',
        'time': '%H:%M:%S',
        'registration_date': '%Y-%m-%d %H:%M:%S'
    })
    cursor.close()
    return render_template('main/my_registrations.html', registrations=registrations)

@main_bp.route('/event/<int:event_id>/cancel', methods=['POST'])
@login_required
def cancel_registration(event_id):
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    try:
        cursor.execute('''
            SELECT * FROM event_registrations 
            WHERE event_id = %s AND user_id = %s
        ''', (event_id, current_user.id))

        if cursor.fetchone():
            cursor.execute('''
                DELETE FROM event_registrations 
                WHERE event_id = %s AND user_id = %s
            ''', (event_id, current_user.id))
            mysql.connection.commit()
            flash('Your registration has been cancelled successfully.', 'success')
        else:
            flash('You are not registered for this event.', 'error')

    except Exception:
        mysql.connection.rollback()
        flash('An error occurred while cancelling your registration.', 'error')
    finally:
        cursor.close()

    return redirect(url_for('main.my_registrations'))
